import networkx as nx

# Διαβάζουμε τον γράφο από το αρχείο.
g1 = nx.read_gml('friendships.gml')


# Ερώτηση 1.
# Βρίσκουμε τις τιμές για τον κόμβο 100.
degree_centrality = nx.degree_centrality(g1)[100]
closeness_centrality = nx.closeness_centrality(g1)[100]
between_centrality = nx.betweenness_centrality(
    g1, endpoints=False, normalized=True)[100]
print("Degree centrality: ", degree_centrality)
print("Closeness centrality: ", closeness_centrality)
print("Betweenness centrality: ", between_centrality)


# Ερώτηση 2.
degree = nx.degree_centrality(g1)
print(max(degree.keys(), key=lambda x: degree[x]))


# Ερώτηση 3.
closeness = nx.closeness_centrality(g1)
print(max(closeness.keys(), key=lambda x: closeness[x]))


# Ερώτηση 4.
betweeness = nx.betweenness_centrality(g1)
print(max(betweeness.keys(), key=lambda x: betweeness[x]))


# Διαβάζουμε τον γράφο από το αρχείο.
g2 = nx.read_gml('blogs.gml')


# Ερώτηση 5.
pr = nx.pagerank(g2, alpha=0.85)
print(pr['realclearpolitics.com'])


# Ερώτηση 6.
pr = nx.pagerank(g2, alpha=0.85)
print(sorted(pr.keys(), key=lambda key: pr[key], reverse=True)[:5])


# Ερώτηση 7.
hits = nx.hits(g2)
node = 'realclearpolitics.com'
print("Hub score:", hits[0][node], " Authority score:", hits[1][node])


# Ερώτηση 8.
hits = nx.hits(g2)
hubs = hits[0]
print(sorted(hubs.keys(), key=lambda key: hubs[key], reverse=True)[:5])


# Ερώτηση 9.
hits = nx.hits(g2)
authorities = hits[1]
print(sorted(authorities.keys(), key=lambda key: authorities[key], reverse=True)[:5])
